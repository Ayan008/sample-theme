<?php



// page heading option start

function page_heading_opt(){
	
	
$pagehead = new_cmb2_box(array(
			'title'			=>__('page heading option','victory'),
			'id'			=>'page-head-opt',
			'object_types'	=>array('page'),
			));
			
		$pagehead->add_field( array(
		'name'	=>	__('Page Heading','victory'),
		'desc'	=>	__('Visibility - this option will not work in Home page template and Post page, you can find this option in theme option','victory'),
		'id'   => 'pagehead-v',
		'type' => 'checkbox',
		) );
		$pagehead->add_field( array(
		'name'	=>	__('Page Heading Descricption','victory'),
		'desc'	=>	__('This option will not work in Home page template and Post page','victory'),
		'id'   => 'pagehead-desc',
		'type' => 'textarea',
		) );
		$pagehead->add_field(array(
		'name'		=>__('Page Heading Background Image','victory'),
		'desc'    	=>__('This option will not work in Home page template and Post page','victory'),
		'id'		=>'pageheadb-img',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Add Image', 
					),
		));
		$pagehead->add_field(array(
			'name'		=>__('Page Heading Background Color','victory'),
			'desc'    	=>__('This option will not work in Home page template and Post page','victory'),
			'id'		=>'pageheadb-color',
			'type'		=>'colorpicker',
			'default' => '#000000',
			'options' => array(
				'alpha' => true, // Make this a rgba color picker.
			),
		));
		
}
add_action('cmb2_admin_init','page_heading_opt');


// page heading option end



// menu custome box start

function food_item_opt(){
	
$menu1 = new_cmb2_box(array(
			'title'=>__('Food Item Option','victory'),
			'id'=>'item-opt',
			'object_types'=>array('menu-1'),
		));
	$menu1->add_field(array(
		'name'=>__('Add Price','victory'),
		'id'=>'add-price',
		'type'=>'text_money',
		'before_field' => '&#2547;',
	));
	
	
	


	
	
	
	
	
$menu2 = new_cmb2_box(array(
			'title'=>__('Food Item Option','victory'),
			'id'=>'item-opt2',
			'object_types'=>array('menu-2'),
		));
	$menu2->add_field(array(
		'name'=>__('Add Price','victory'),
		'id'=>'add-price2',
		'type'=>'text_money',
		'before_field' => '&#2547;',
	));
	


	
	
	
	
	
	
$menu3 = new_cmb2_box(array(
			'title'=>__('Food Item Option','victory'),
			'id'=>'item-opt3',
			'object_types'=>array('menu-3'),
		));
	$menu3->add_field(array(
		'name'=>__('Add Price','victory'),
		'id'=>'add-price3',
		'type'=>'text_money',
		'before_field' => '&#2547;',
	));	
	


	
		
	
}
add_action('cmb2_admin_init','food_item_opt');

// menu custome box end


// home template custome box start

 function home_page_template_opt(){
	
   
 $hometemp = new_cmb2_box( array(
		 'title'        => __('Home Page Template Option','victory'),
		 'id'           => 'home-temp-opt',
		 'object_types' => array( 'page' ), // post type
		 'show_on'      => array( 'key' => 'page-template', 'value' => 'template/home.php' ),
	 ) );
	 
	// section-1 start
	
	$hometemp->add_field( array(
		'name'	=>	__('Section-1','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'home-sec1-v',
		'type' => 'checkbox',
	) );
	$hometemp->add_field(array(
		'name'		=>__('Section-1 Background Image','victory'),
		'desc'    	=>__('Upload a image to show as backkground of home page template Section-1','victory'),
		'id'		=>'home-sec1-bimg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Add Background Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-1 Background Color','victory'),
		'desc'    	=>__('Select a color to show as backkground of home page template Section-1','victory'),
		'id'		=>'home-sec1-bcolor',
		'type'		=>'colorpicker',
		'default' => '#ffffff',
		'options' => array(
			'alpha' => true, // Make this a rgba color picker.
		),
	));
	$hometemp->add_field( array(
		'name'    => __('Section-1 content','victory'),
		'desc'    => __('Add content to display center of section-1','victory'),
		'id'      => 'home-sec1-content',
		'type'    => 'wysiwyg',
	) );
	// section-1 end
	
	// section-2 start
	
	$hometemp->add_field( array(
		'name'	=>	__('Section-2','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'home-sec2-v',
		'type' => 'checkbox',
	) );
	$hometemp->add_field(array(
		'name'		=>__('Section-2 Background Image','victory'),
		'desc'    	=>__('Upload a image to show as backkground of home page template Section-2','victory'),
		'id'		=>'home-sec2-bimg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Add Background Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-2 Background Color','victory'),
		'desc'    	=>__('Select a color to show as backkground color of home page template Section-2','victory'),
		'id'		=>'home-sec2-bcolor',
		'type'		=>'colorpicker',
		'default' => '#ffffff',
		'options' => array(
			'alpha' => true, // Make this a rgba color picker.
		),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-2 Card Left Image','victory'),
		'desc'    	=>__('Upload a image to show as Card Light Image','victory'),
		'id'		=>'home-sec2-climg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Card Left Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-2 Card Right Image','victory'),
		'desc'    	=>__('Upload a image to show as Card Right Image','victory'),
		'id'		=>'home-sec2-crimg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Card Right Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-2 Card Background Color','victory'),
		'desc'    	=>__('Select a color to show as background color of contact card','victory'),
		'id'		=>'home-sec2-card-bcolor',
		'type'		=>'colorpicker',
		'default' => '#f2745f',
		'options' => array(
			'alpha' => true, // Make this a rgba color picker.
		),
	));
	$hometemp->add_field( array(
		'name'    => __('Section-2 Card content','victory'),
		'desc'    => __('Add content to show on card','victory'),
		'id'      => 'home-sec2-card-content',
		'type'    => 'wysiwyg',
	) );
	
	// section-2 end
	
	// section-3 start
	$hometemp->add_field( array(
		'name'	=>	__('Section-3','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'home-sec3-v',
		'type' => 'checkbox',
	) );
	$hometemp->add_field(array(
		'name'		=>__('Section-3 Background Image','victory'),
		'desc'    	=>__('Upload a image to show as backkground of home page template Section-3','victory'),
		'id'		=>'home-sec3-bimg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Add Background Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-3 Background Color','victory'),
		'desc'    	=>__('Select a color to show as backkground color of home page template Section-3','victory'),
		'id'		=>'home-sec3-bcolor',
		'type'		=>'colorpicker',
		'default' => '#ffffff',
		'options' => array(
			'alpha' => true, // Make this a rgba color picker.
		),
	));
	$hometemp->add_field( array(
		'name' => __( 'Page URL', 'victory' ),
		'desc' => __( 'Copy your menu page URL and paste here , so that visitor can reach your menu page by click here', 'victory' ),
		'id'   => 'home-sec3-menu-link',
		'type' => 'text_url',
	) );
	// section-3 end
	
	// section-4 start
	
	$hometemp->add_field( array(
		'name'	=>	__('Section-4','victory'),
		'desc'	=>	__('Visibility- this section show from Reservation section ','victory'),
		'id'   => 'home-sec4-v',
		'type' => 'checkbox',
	) );
	
	// section-4 end
	
	
	// section-5 start
	$hometemp->add_field( array(
		'name'	=>	__('Section-5','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'home-sec5-v',
		'type' => 'checkbox',
	) );
	$hometemp->add_field(array(
		'name'		=>__('Section-5 Background Image','victory'),
		'desc'    	=>__('Upload a image to show as backkground of home page template Section-5','victory'),
		'id'		=>'home-sec5-bimg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Add Background Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-5 Background Color','victory'),
		'desc'    	=>__('Select a color to show as backkground color of home page template Section-5','victory'),
		'id'		=>'home-sec5-bcolor',
		'type'		=>'colorpicker',
		'default' => '#f2745f',
		'options' => array(
			'alpha' => true, // Make this a rgba color picker.
		),
	));
	$hometemp->add_field( array(
		'name'    => __('Section-5 content','victory'),
		'desc'    => __('Add content to display in section-5','victory'),
		'id'      => 'home-sec5-content',
		'type'    => 'wysiwyg',
	) );
	// section-5 end
	
	
	// section-6 start
	$hometemp->add_field( array(
		'name'	=>	__('Section-6','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'home-sec6-v',
		'type' => 'checkbox',
	) );
	$hometemp->add_field(array(
		'name'		=>__('Section-6 Background Image','victory'),
		'desc'    	=>__('Upload a image to show as backkground of home page template Section-6','victory'),
		'id'		=>'home-sec6-bimg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Add Background Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-6 Background Color','victory'),
		'desc'    	=>__('Select a color to show as backkground color of home page template Section-6','victory'),
		'id'		=>'home-sec6-bcolor',
		'type'		=>'colorpicker',
		'default' => '#ffffff',
		'options' => array(
			'alpha' => true, // Make this a rgba color picker.
		),
	));
	$hometemp->add_field( array(
		'name'	=>	__('Section-6 Heading','victory'),
		'id'   => 'home-sec6-head',
		'type' => 'text',
	) );
	// section-6 end
	
	
	// section-7 start
	$hometemp->add_field( array(
		'name'	=>	__('Section-7','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'home-sec7-v',
		'type' => 'checkbox',
	) );
	$hometemp->add_field(array(
		'name'		=>__('Section-7 Background Image','victory'),
		'desc'    	=>__('Upload a image to show as backkground of home page template Section-7','victory'),
		'id'		=>'home-sec7-bimg',
		'type'		=>'file',
		'text'    => array(
						'add_upload_file_text' => 'Add Background Image', 
					),
	));
	$hometemp->add_field(array(
		'name'		=>__('Section-7 Background Color','victory'),
		'desc'    	=>__('Select a color to show as backkground color of home page template Section-7','victory'),
		'id'		=>'home-sec7-bcolor',
		'type'		=>'colorpicker',
		'default' => '#ffffff',
		'options' => array(
			'alpha' => true, // Make this a rgba color picker.
		),
	));
	$hometemp->add_field( array(
		'name'	=>	__('Section-7 Heading','victory'),
		'id'   => 'home-sec7-head',
		'type' => 'text',
	) );
	// section-7 end
	

	
 }
 add_action('cmb2_admin_init','home_page_template_opt');
 
// home template custome box end



// page heading option start

function reservation_option(){
	
	
$reservation = new_cmb2_box(array(
			'title'			=>__('Reservation option','victory'),
			'id'			=>'reservation-opt',
			'object_types'	=>array('page'),
			'show_on'      => array( 'key' => 'page-template', 'value' => 'template/menu.php' ),
			));
			
	$reservation->add_field( array(
		'name'	=>	__('Reservation Section','victory'),
		'desc'	=>	__('Visibility ','victory'),
		'id'   => 'reservation-sec-v',
		'type' => 'checkbox',
	) );
			
	
	
		
		
}
add_action('cmb2_admin_init','reservation_option');



// contact page 

function contact_page_opt(){
	
	
$contact = new_cmb2_box(array(
			'title'			=>__('Contact Page option','victory'),
			'id'			=>'contact-page-opt',
			'object_types'	=>array('page'),
			'show_on'      => array( 'key' => 'page-template', 'value' => 'template/contact.php' ),
			));
			
		$contact->add_field( array(
		'name'	=>	__('Section-1 Option','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'con-sec-v',
		'type' => 'checkbox',
		) );
		$contact->add_field( array(
		'name'	=>	__('Section-1 Left side Heading','victory'),
		'id'   => 'con-sec1-lfh',
		'type' => 'text',
		) );
		$contact->add_field( array(
		'name'	=>	__('Section-1 Left side form shortcode','victory'),
		'desc'	=>	__('Paste a contact form shortcode here.','victory'),
		'id'   => 'con-sec1-form-shortcode',
		'type' => 'text',
		) );
		$contact->add_field( array(
		'name'	=>	__('Section-1 Right side Heading','victory'),
		'id'   => 'con-sec1-rgh',
		'type' => 'text',
		) );
		$contact->add_field( array(
		'name'	=>	__('Section-1 Right side Content','victory'),
		'desc'	=>	__('Upload Your content here','victory'),
		'id'   => 'con-sec1-rgcon',
		'type' => 'wysiwyg',
		) );
		
		$contact->add_field( array(
		'name'	=>	__('Map Option','victory'),
		'desc'	=>	__('Visibility','victory'),
		'id'   => 'con-map-v',
		'type' => 'checkbox',
		) );
		$contact->add_field( array(
		'name'	=>	__('Make Your More Content','victory'),
		'desc'	=>	__('You can add some more content or a map. Just use the page editor. Also you can add a map by HTML code','victory'),
		'id'   => 'con-tem-map',
		'type' => 'title',
		) );
		
		
}
add_action('cmb2_admin_init','contact_page_opt');


function subscribe_form(){
$subscribe = new_cmb2_box(array(
			'title'			=>__('Subscription option','victory'),
			'id'			=>'subscription-opt',
			'object_types'	=>array('page'),
			));
			
		$subscribe->add_field( array(
		'name'	=>	__('Subscription Visibility','victory'),
		'desc'	=>	__('Visibility-This option will not work in post page, you can find this option in theme option','victory'),
		'id'   => 'subs-v',
		'type' => 'checkbox',
		) );
}
add_action('cmb2_admin_init','subscribe_form');





