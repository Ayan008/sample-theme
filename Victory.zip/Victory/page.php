<?php get_header(); ?>
<?php global $victory;?>

    <?php get_template_part('template/page-head'); ?>


    <section class="page">
	<?php while(have_posts()): the_post(); ?>
        <p><?php the_post_thumbnail(); ?><?php the_content(); ?></p>
	<?php endwhile; ?>
    </section>

<?php get_template_part('template/newsletter'); ?>


<?php get_footer(); ?>