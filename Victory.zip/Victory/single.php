<?php get_header(); ?>
<?php global $victory;?>

    <section class="page-heading">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
				<?php while(have_posts()): the_post(); ?>
                    <h1><?php the_title(); ?></h1>
                    <p>Post BY - <?php the_author(); ?></p>
                    <p>Post AT - <?php the_time('j M Y'); ?></p>
                <?php endwhile; ?>
				</div>
            </div>
        </div>
    </section>


    <section class="blog-page">
        <div class="container">
            <div class="row">
			
			<?php while(have_posts()): the_post(); ?>
		
                <div class="col-md-8 col-md-offset-2">
                    <div class="blog-item">
                        <?php the_post_thumbnail(); ?>
                        <div class="date"><?php the_time('j M Y'); ?></div>
                        <div class="down-content">
                            
							<?php if(has_post_thumbnail()): ?>
							
								<h4><?php the_title(); ?></h4>
							
							<?php else: ?>
							
								<h4 class="without-thumbnail" ><?php the_title(); ?></h4>
							
							<?php endif; ?>
							
                            <span>Post BY - <?php the_author(); ?></span>
                            <p><?php the_content(); ?></p>
                            <div class="text-button">
                                <a href="javascript:history.back()">Click to go Back</a>
                            </div>
							
                        </div>
                    </div>
                </div>
				
			<?php endwhile; ?>	
                
                
            </div>
        </div>
    </section>

<?php get_template_part('template/newsletter'); ?>


<?php get_footer(); ?>