<?php get_header(); ?>
<?php global $victory;?>

    <section class="page-heading">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php while(have_posts()): the_post(); ?>
                    <h1><?php the_title(); ?></h1>
                    <h3 style="color: #ffffff" >
					Menu Type - <?php echo $victory['food-menu3-name'];?>
					</h3>
                    <p>Post BY - <?php the_author(); ?></p>
                    <p>Post AT - <?php the_time('j M Y'); ?></p>
					<?php endwhile; ?>
                </div>
            </div>
        </div>
    </section>


    <section class="blog-page">
        <div class="container">
            <div class="row">
			
			<?php while(have_posts()): the_post(); ?>
				<div class="item col-md-9">
					<div class="food-item single-menu">
						<?php the_post_thumbnail(); ?>
						<div class="price single-menu-price">
						<?php echo get_post_meta(get_the_id(),'add-price3',true); ?>
						</div>
						<div class="text-content" style="
						background-color: <?php echo get_post_meta(get_the_id(),'text-bcolor3',true); ?>" >
						
							<h4 style="
						color: <?php echo get_post_meta(get_the_id(),'text-hcolor3',true); ?>
						" ><a href=""><?php the_title(); ?></a></h4>
						
							<p style="
						color: <?php echo get_post_meta(get_the_id(),'text-color3',true); ?>
						" ><?php the_content(); ?></p>
						<a href="javascript:history.back()" class="single-menu-back-btn">CLICK HERE TO GO BACK</a>
						</div>
						
					</div>
				</div>
			<?php endwhile; ?>
                
                
            </div>
        </div>
    </section>


 <?php get_template_part('template/newsletter'); ?>


<?php get_footer(); ?>