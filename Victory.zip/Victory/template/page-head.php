<?php global $victory;?>
<?php while(have_posts()): the_post(); ?>
<?php if ( get_post_meta( get_the_ID(), 'pagehead-v', 1 ) ) : ?>
<section class="page-heading"
	 style="
		background-image:url(<?php echo get_post_meta(get_the_id(),'pageheadb-img',true); ?>);
		background-color:<?php echo get_post_meta(get_the_id(),'pageheadb-color',true); ?>;
	" >
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1><?php wp_title('',true,''); ?></h1>
				<p>
				<?php echo get_post_meta(get_the_id(),'pagehead-desc',true); ?>
				</p>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
<?php endwhile;?>