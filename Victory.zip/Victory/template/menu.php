<?php 

// Template name: Our Menu Page

get_header(); global $victory; ?>


    <?php get_template_part('template/page-head'); ?>



    <section class="breakfast-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="breakfast-menu-content" style= "
  background-color: <?php echo $victory['food-menu1-background-opt']['background-color']; ?>;
  background-image: url(<?php echo $victory['food-menu1-background-opt']['background-image']; ?>);
  background-repeat: <?php echo $victory['food-menu1-background-opt']['background-repeat']; ?>;
  background-position: <?php echo $victory['food-menu1-background-opt']['background-position']; ?>;
  background-attachment: <?php echo $victory['food-menu1-background-opt']['background-attachment']; ?>;
  background-size: <?php echo $victory['food-menu1-background-opt']['background-size']; ?>;
  ">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="left-image">
								<img src="<?php echo $victory['food-menu1-thumb-img']['url'];?>" alt="" />	
                                </div>
                            </div>
                            <div class="col-md-7">
                                <h2><?php echo $victory['food-menu1-name'];?></h2>
                                <div id="owl-breakfast" class="owl-carousel owl-theme">
								<?php 
										
									$foodmenu1 = new WP_Query(array(
										'post_type' => 'menu-1',
									));
								
								while($foodmenu1->have_posts()): $foodmenu1->the_post(); ?>
								
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <?php the_post_thumbnail(); ?>
                                            <div class="price">
											<?php echo get_post_meta(get_the_id(),'add-price',true); ?>
											</div>
                                            <div class="text-content">
											
                                            <h4>
											<a href="<?php the_permalink();?>">
											<?php the_title(); ?>
											</a>
											</h4>
											
                                            <p><?php echo wp_trim_words(get_the_content(),20,'...'); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="lunch-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="lunch-menu-content" style= "
  background-color: <?php echo $victory['food-menu2-background-opt']['background-color']; ?>;
  background-image: url(<?php echo $victory['food-menu2-background-opt']['background-image']; ?>);
  background-repeat: <?php echo $victory['food-menu2-background-opt']['background-repeat']; ?>;
  background-position: <?php echo $victory['food-menu2-background-opt']['background-position']; ?>;
  background-attachment: <?php echo $victory['food-menu2-background-opt']['background-attachment']; ?>;
  background-size: <?php echo $victory['food-menu2-background-opt']['background-size']; ?>;
  ">
                        <div class="row">
                            <div class="col-md-7">
                                <h2><?php echo $victory['food-menu2-name'];?></h2>
                                <div id="owl-lunch" class="owl-carousel owl-theme">
								<?php 
										
									$foodmenu2 = new WP_Query(array(
										'post_type' => 'menu-2',
									));
								
								
								
								while($foodmenu2->have_posts()): $foodmenu2->the_post(); ?>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <?php the_post_thumbnail(); ?>
                                            <div class="price">
											<?php echo get_post_meta(get_the_id(),'add-price2',true); ?>
											</div>
                                             <div class="text-content" >
											
                                                <h4><a href="<?php the_permalink();?>">
											<?php the_title(); ?>
											</a></h4>
											
                                                <p><?php echo wp_trim_words(get_the_content(),20,'...'); ?></p>
                                            </div>
                                        </div>
                                    </div>
								<?php endwhile; ?>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="left-image">
                                    
									<img src="<?php echo $victory['food-menu2-thumb-img']['url'];?>" alt="" />	
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="dinner-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="dinner-menu-content" style= "
  background-color: <?php echo $victory['food-menu3-background-opt']['background-color']; ?>;
  background-image: url(<?php echo $victory['food-menu3-background-opt']['background-image']; ?>);
  background-repeat: <?php echo $victory['food-menu3-background-opt']['background-repeat']; ?>;
  background-position: <?php echo $victory['food-menu3-background-opt']['background-position']; ?>;
  background-attachment: <?php echo $victory['food-menu3-background-opt']['background-attachment']; ?>;
  background-size: <?php echo $victory['food-menu3-background-opt']['background-size']; ?>;
  ">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="left-image">
                                    <img src="<?php echo $victory['food-menu3-thumb-img']['url'];?>" alt="">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <h2><?php echo $victory['food-menu3-name'];?></h2>
                                <div id="owl-dinner" class="owl-carousel owl-theme">
								<?php 
										
									$foodmenu3 = new WP_Query(array(
										'post_type' => 'menu-3',
									));
								
								
								
								while($foodmenu3->have_posts()): $foodmenu3->the_post(); ?>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <?php the_post_thumbnail(); ?>
                                            <div class="price">
											<?php echo get_post_meta(get_the_id(),'add-price3',true); ?>
											</div>
                                            <div class="text-content">
											
                                                <h4><a href="<?php the_permalink();?>">
											<?php the_title(); ?>
											</a></h4>
											
                                                <p><?php echo wp_trim_words(get_the_content(),20,'...'); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                   <?php endwhile; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	



<?php while(have_posts()): the_post(); ?>
<?php if ( get_post_meta( get_the_ID(), 'reservation-sec-v', 1 ) ) : ?>
    <section id="book-table" style= "
  background-color: <?php echo $victory['reserv-section-background-opt']['background-color']; ?>;
  background-image: url(<?php echo $victory['reserv-section-background-opt']['background-image']; ?>);
  background-repeat: <?php echo $victory['reserv-section-background-opt']['background-repeat']; ?>;
  background-position: <?php echo $victory['reserv-section-background-opt']['background-position']; ?>;
  background-attachment: <?php echo $victory['reserv-section-background-opt']['background-attachment']; ?>;
  background-size: <?php echo $victory['reserv-section-background-opt']['background-size']; ?>;
  ">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="heading">
                        <h2><?php echo get_post_meta(get_the_ID(),'home-sec4-head',true); ?></h2>
                    </div>
                </div>
                <div class="col-md-4 col-md-offset-2 col-sm-12">
                    <div class="left-image">
                      <img src="<?php echo $victory['reserv-form-legt-img']['url']; ?>" alt="">
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="right-info" style= "
	  background-color: <?php echo $victory['reserv-form-background-opt']['background-color']; ?>;
	  background-image: url(<?php echo $victory['reserv-form-background-opt']['background-image']; ?>);
	  background-repeat: <?php echo $victory['reserv-form-background-opt']['background-repeat']; ?>;
	  background-position: <?php echo $victory['reserv-form-background-opt']['background-position']; ?>;
	  background-attachment: <?php echo $victory['reserv-form-background-opt']['background-attachment']; ?>;
	  background-size: <?php echo $victory['reserv-form-background-opt']['background-size']; ?>;
  ">
                        <h4><?php echo $victory['reserv-form-heading']; ?></h4>
						
						
						<?php echo do_shortcode($victory['reserv-form-shortcode']); ?>
					<!--<form id="form-submit" action="" method="get">
                            <div class="row">
                                <div class="col-md-6">
                                    <fieldset>
                                        <select required name='day' onchange='this.form.()'>
                                            <option value="">Select day</option>
                                            <option value="Monday">Monday</option>
                                            <option value="Tuesday">Tuesday</option>
                                            <option value="Wednesday">Wednesday</option>
                                            <option value="Thursday">Thursday</option>
                                            <option value="Friday">Friday</option>
                                            <option value="Saturday">Saturday</option>
                                            <option value="Sunday">Sunday</option>
                                        </select>
                                    </fieldset>
                                </div>
                                <div class="col-md-6">
                                    <fieldset>
                                        <select required name='hour' onchange='this.form.()'>
                                            <option value="">Select hour</option>
                                            <option value="10-00">10:00</option>
                                            <option value="12-00">12:00</option>
                                            <option value="14-00">14:00</option>
                                            <option value="16-00">16:00</option>
                                            <option value="18-00">18:00</option>
                                            <option value="20-00">20:00</option>
                                            <option value="22-00">22:00</option>
                                        </select>
                                    </fieldset>
                                </div>
                                <div class="col-md-6">
                                    <fieldset>
                                        <input name="name" type="name" class="form-control" id="name" placeholder="Full name" required>
                                    </fieldset> 
                                </div>
                                <div class="col-md-6">
                                    <fieldset>
                                        <input name="phone" type="phone" class="form-control" id="phone" placeholder="Phone number" required>
                                    </fieldset>
                                </div>
                                <div class="col-md-6">
                                    <fieldset>
                                        <select required class="person" name='persons' onchange='this.form.()'>
                                            <option value="">How many persons?</option>
                                            <option value="1-Person">1 Person</option>
                                            <option value="2-Persons">2 Persons</option>
                                            <option value="3-Persons">3 Persons</option>
                                            <option value="4-Persons">4 Persons</option>
                                            <option value="5-Persons">5 Persons</option>
                                            <option value="6-Persons">6 Persons</option>
                                        </select>
                                    </fieldset>
                                </div>
                                <div class="col-md-6">
                                    <fieldset>
                                        <button type="submit" id="form-submit" class="btn">Book Table</button>
                                    </fieldset>
                                </div>
                            </div>
                        </form>-->
						
						
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php  endif; ?>
<?php endwhile; ?>	

<?php get_template_part('template/newsletter'); ?>

<?php get_footer(); ?>