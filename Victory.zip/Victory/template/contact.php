<?php 

// Template name: Contact US Page

get_header(); global $victory;?>


    <?php get_template_part('template/page-head'); ?>


<?php while(have_posts()): the_post(); ?>
<?php if( get_post_meta ( get_the_id() , 'con-sec-v' , 1 ) ): ?>
    <section class="contact-us">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="section-heading">
                        <h2><?php echo get_post_meta(get_the_id(),'con-sec1-lfh',true); ?></h2>
                    </div>
					
					<?php echo do_shortcode(get_post_meta(get_the_id(),'con-sec1-form-shortcode',true)); ?>
					
				<!--<form id="contact" action="" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <fieldset>
                                    <input name="name" type="text" class="form-control" id="name" placeholder="Your name..." required>
                                </fieldset>
                                <fieldset>
                                    <input name="email" type="text" class="form-control" id="email" placeholder="Your email..." required>
                                </fieldset>
                                <fieldset>
                                    <input name="phone" type="text" class="form-control" id="phone" placeholder="Your phone..." required>
                                </fieldset>
                            </div>
                            <div class="col-md-6">
                                <fieldset>
                                    <textarea name="message" rows="6" class="form-control" id="message" placeholder="Your message..." required></textarea>
                                </fieldset>
                                <fieldset>
                                    <button type="submit" id="form-submit" class="btn">Send Message</button>
                                </fieldset>
                            </div>
                        </div>
                    </form>-->
                </div>
                <div class="col-md-6">
                    <div class="section-heading contact-info">
                        <h2><?php echo get_post_meta(get_the_id(),'con-sec1-rgh',true); ?></h2>
                        <p><?php echo get_post_meta(get_the_id(),'con-sec1-rgcon',true); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>	
<?php endwhile; ?>



<?php while(have_posts()): the_post(); ?>
<?php if( get_post_meta ( get_the_id() , 'con-map-v' , 1 ) ): ?>
    <section class="map">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div id="map">
        <!-- How to change your own map point
            1. Go to Google Maps
            2. Click on your location point
            3. Click "Share" and choose "Embed map" tab
            4. Copy only URL and paste it within the src="" field below
			
        -->	
		  <?php the_content(); ?>
		  <?php echo get_post_meta(get_the_id(),'con-tem-map',true); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>	
<?php endwhile; ?>

<?php get_template_part('template/newsletter'); ?>

<?php get_footer(); ?>