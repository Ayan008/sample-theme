<?php global $victory;?>
<?php while(have_posts()): the_post(); ?>
<?php if ( get_post_meta( get_the_ID(), 'subs-v', 1 ) ) : ?>
<section class="sign-up" style= "
	  background-color: <?php echo $victory['subs-form-background-opt']['background-color']; ?>;
	  background-image: url(<?php echo $victory['subs-form-background-opt']['background-image']; ?>);
	  background-repeat: <?php echo $victory['subs-form-background-opt']['background-repeat']; ?>;
	  background-position: <?php echo $victory['subs-form-background-opt']['background-position']; ?>;
	  background-attachment: <?php echo $victory['subs-form-background-opt']['background-attachment']; ?>;
	  background-size: <?php echo $victory['subs-form-background-opt']['background-size']; ?>;
  ">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="heading">
					<h2><?php echo $victory['subs-form-heading']; ?></h2>
				</div>
			</div>
		</div>
		
		
		<?php echo do_shortcode($victory['subs-form-shortcode']); ?>
	<!--<form id="contact" action="" method="get">
			<div class="row">
				<div class="col-md-4 col-md-offset-3">
					<fieldset>
						<input name="email" type="text" class="form-control" id="email" placeholder="Enter your email here..." required>
					</fieldset>
				</div>
				<div class="col-md-2">
					<fieldset>
						<button type="submit" id="form-submit" class="btn">Send Message</button>
					</fieldset>
				</div>
			</div>
		</form>-->
		
	</div>
</section>
<?php endif; ?>
<?php endwhile;?>