<?php get_header(); ?>
<?php global $victory;?>  

    
<?php if($victory['post-page-head-opt'] == 1 ): ?>
<section class="page-heading">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1><?php wp_title('',true,''); ?></h1>
				<p><?php echo $victory['post-page-head-desc']; ?></p>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
	


    <section class="blog-page">
	<?php if(have_posts()): ?>
        <div class="container">
            <div class="row">
			
			<?php while(have_posts()): the_post(); ?>
		
                <div class="col-md-8 col-md-offset-2">
                    <div class="blog-item">
                        <?php the_post_thumbnail(); ?>
                        <div class="date"><?php the_time('j M Y'); ?></div>
                        <div class="down-content">
						
							<?php if(has_post_thumbnail()): ?>
							
								<h4><?php the_title(); ?></h4>
							
							<?php else: ?>
							
								<h4 class="without-thumbnail" ><?php the_title(); ?></h4>
							
							<?php endif; ?>
							
                            <span>Post BY - <?php the_author(); ?></span>
                            <p><?php echo wp_trim_words(get_the_content(),50,'...</p>
                            <div class="text-button">
                                <a href="'.get_the_permalink().'">Continue Reading</a>
                            </div>
							'); ?>
                        </div>
                    </div>
                </div>
				
			<?php endwhile; ?>	
                
                <div class="col-md-8 col-md-offset-2">
                    <ul class="page-number">
                      <!--<li><a href="#">1</a></li>
                       <li class="active"><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">&gt;&gt;</a></li>-->
						<?php the_posts_pagination(array(
							'screen_reader_text'=>' ',
							'prev_text'=>'&lt;&lt;',
							'next_text'=>'&gt;&gt;',
						)); ?>
                    </ul>
					
                </div>
            </div>
        </div>
	<?php else:?>
		<h1 class="no-post">Oops! NO POST FOUND</h1>
	<?php endif; ?>
    </section>

<?php if($victory['post-page-subs-fom'] == 1 ): ?>
<section class="sign-up" style= "
	  background-color: <?php echo $victory['subs-form-background-opt']['background-color']; ?>;
	  background-image: url(<?php echo $victory['subs-form-background-opt']['background-image']; ?>);
	  background-repeat: <?php echo $victory['subs-form-background-opt']['background-repeat']; ?>;
	  background-position: <?php echo $victory['subs-form-background-opt']['background-position']; ?>;
	  background-attachment: <?php echo $victory['subs-form-background-opt']['background-attachment']; ?>;
	  background-size: <?php echo $victory['subs-form-background-opt']['background-size']; ?>;
  ">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="heading">
					<h2><?php echo $victory['subs-form-heading']; ?></h2>
				</div>
			</div>
		</div>
		
		<?php echo do_shortcode($victory['subs-form-shortcode']); ?>
	<!--<form id="contact" action="" method="get">
			<div class="row">
				<div class="col-md-4 col-md-offset-3">
					<fieldset>
						<input name="email" type="text" class="form-control" id="email" placeholder="Enter your email here..." required>
					</fieldset>
				</div>
				<div class="col-md-2">
					<fieldset>
						<button type="submit" id="form-submit" class="btn">Send Message</button>
					</fieldset>
				</div>
			</div>
		</form>-->
		
		
	</div>
</section>
<?php endif; ?>

<?php get_footer(); ?>