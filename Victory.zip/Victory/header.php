<!DOCTYPE html>
<html <?php language_attributes(); global $victory;?> >
    <head>
        <meta charset="utf-8">
        

        
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo $victory['fav-up']['url'] ?>" />
<!-- custome css-->		
<style type="text/css"> 

<?php echo $victory['custom-css-code']; ?>

</style>		
<!-- custome css-->		
		
<?php wp_head(); ?>
    </head>

<body style= "
	  background-color: <?php echo $victory['theme-background-opt']['background-color']; ?>;
	  background-image: url(<?php echo $victory['theme-background-opt']['background-image']; ?>);
	  background-repeat: <?php echo $victory['theme-background-opt']['background-repeat']; ?>;
	  background-position: <?php echo $victory['theme-background-opt']['background-position']; ?>;
	  background-attachment: <?php echo $victory['theme-background-opt']['background-attachment']; ?>;
	  background-size: <?php echo $victory['theme-background-opt']['background-size']; ?>;
  ">
    <div class="header" style= "
	  background-color: <?php echo $victory['header-background-opt']['background-color']; ?>;
	  background-image: url(<?php echo $victory['header-background-opt']['background-image']; ?>);
	  background-repeat: <?php echo $victory['header-background-opt']['background-repeat']; ?>;
	  background-position: <?php echo $victory['header-background-opt']['background-position']; ?>;
	  background-attachment: <?php echo $victory['header-background-opt']['background-attachment']; ?>;
	  background-size: <?php echo $victory['header-background-opt']['background-size']; ?>;
  ">
        <div class="container">
			<div class="logo">
				<a href="<?php echo home_url(); ?>" >
					<?php if($victory['logo-up']['url']): ?>
					
						<img src="<?php echo $victory['logo-up']['url'];?>" alt="">
					
					<?php else: ?>
					
						<h2><?php echo $victory['logo-text']; ?></h2>
					
					<?php endif; ?>
				</a>
			</div>
			<hr style="
				border-top: <?php echo $victory['header-separator']['border-top']; ?>; 
				border-bottom: <?php echo $victory['header-separator']['border-bottom']; ?>; 
				border-left: <?php echo $victory['header-separator']['border-left']; ?>;  
				border-right: <?php echo $victory['header-separator']['border-right']; ?>;
				border-style: <?php echo $victory['header-separator']['border-style']; ?>;
				border-color: <?php echo $victory['header-separator']['border-color']; ?>;  
			" />
            <nav class="navbar navbar-inverse" role="navigation">
                <div class="navbar-header">
                    <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <!--/.navbar-header-->
                <div id="main-nav" class="collapse navbar-collapse">
                    <!--<ul class="nav navbar-nav">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="menu.html">Our Menus</a></li>
                        <li><a href="blog.html">Blog Entries</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                    </ul>-->
					<?php wp_nav_menu(array(
										'theme_location' => 'main-menu',
										'container' => 'nav',
										'fallback_cb'=>'defult_menu',
										'menu_class'=> 'nav navbar-nav'
									)); ?>
                </div>
                <!--/.navbar-collapse-->
            </nav>
            <!--/.navbar-->
        </div>
        <!--/.container-->
    </div>
    <!--/.header-->