<?php global $victory;?>   
	
	<footer style= "
	  background-color: <?php echo $victory['footer-background-opt']['background-color']; ?>;
	  background-image: url(<?php echo $victory['footer-background-opt']['background-image']; ?>);
	  background-repeat: <?php echo $victory['footer-background-opt']['background-repeat']; ?>;
	  background-position: <?php echo $victory['footer-background-opt']['background-position']; ?>;
	  background-attachment: <?php echo $victory['footer-background-opt']['background-attachment']; ?>;
	  background-size: <?php echo $victory['footer-background-opt']['background-size']; ?>;
  ">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <p><?php echo $victory['footer-left-content']; ?></p>
                </div>
                <div class="col-md-4">
                    <ul class="social-icons">
					
					<?php if($victory['footer-icon-link']['facebook']): ?>	
                        <li><a href="<?php echo $victory['footer-icon-link']['facebook']; ?>" >
							<i class="fa fa-facebook"></i>
						</a></li>
					<?php endif; ?>	
					
					<?php if($victory['footer-icon-link']['twitter']): ?>
                        <li><a href="<?php echo $victory['footer-icon-link']['twitter']; ?>">
							<i class="fa fa-twitter"></i>
						</a></li>
					<?php endif; ?>	
					
					<?php if($victory['footer-icon-link']['linkedin']): ?>	
                        <li><a href="<?php echo $victory['footer-icon-link']['linkedin']; ?>">
							<i class="fa fa-linkedin"></i>
						</a></li>
					<?php endif; ?>	
					
					<?php if($victory['footer-icon-link']['rss']): ?>	
                        <li><a href="<?php echo $victory['footer-icon-link']['rss']; ?>">
							<i class="fa fa-rss"></i>
						</a></li>
					<?php endif; ?>	
					
					<?php if($victory['footer-icon-link']['dribbble']): ?>	
                        <li><a href="<?php echo $victory['footer-icon-link']['dribbble']; ?>">
							<i class="fa fa-dribbble"></i>
						</a></li>
					<?php endif; ?>		
						
                    </ul>
                </div>
                <div class="col-md-4">
                    <p><?php echo $victory['footer-right-content']; ?></p>
                </div>
            </div>
        </div>
    </footer>


    <script>window.jQuery || document.write('<script src=<?php get_template_directory_uri(); ?> "/js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
    <script type="text/javascript">
    $(document).ready(function() {
        // navigation click actions 
        $('.scroll-link').on('click', function(event){
            event.preventDefault();
            var sectionID = $(this).attr("data-id");
            scrollToID('#' + sectionID, 750);
        });
        // scroll to top action
        $('.scroll-top').on('click', function(event) {
            event.preventDefault();
            $('html, body').animate({scrollTop:0}, 'slow');         
        });
        // mobile nav toggle
        $('#nav-toggle').on('click', function (event) {
            event.preventDefault();
            $('#main-nav').toggleClass("open");
        });
    });
    // scroll function
    function scrollToID(id, speed){
        var offSet = 0;
        var targetOffset = $(id).offset().top - offSet;
        var mainNav = $('#main-nav');
        $('html,body').animate({scrollTop:targetOffset}, speed);
        if (mainNav.hasClass("open")) {
            mainNav.css("height", "1px").removeClass("in").addClass("collapse");
            mainNav.removeClass("open");
        }
    }
    if (typeof console === "undefined") {
        console = {
            log: function() { }
        };
    }
    </script>
<!--Custome JS-->
<script type="text/javascript"> 
(function($){
        $(document).ready(function(){
		
			<?php echo $victory['custom-js-code']; ?>
		
		});
  })(jQuery)
</script>
<!--Custome JS-->
	
<?php wp_footer(); ?>
</body>
</html>