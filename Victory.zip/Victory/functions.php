<?php

function victory_function(){
	
	add_theme_support('title-tag');
	add_theme_support('custom-header');
	add_theme_support('custom-background');
	add_theme_support('post-thumbnails');
	add_theme_support('post-formats',array('audio','video','gallery')); 
	
	load_theme_textdomain('victory',get_template_directory().'/languages');
	
	register_nav_menus(array(
		'main-menu' => __('Main menu','victory'),
		'footer-menu' => __('Footer menu','victory'),
	));
	
	function defult_menu(){
		
		if(!is_user_logged_in()){
			echo '<ul class="nav navbar-nav">
					<li class="current-menu-item"><a href="'.home_url().'">Home</a></li>
				</ul>';
		}else{echo '<ul class="nav navbar-nav">
					<li><a href="wp-admin/nav-menus.php">Create Menu</a></li>
				</ul>';}
		
	}
	
	
	register_post_type('menu-1',array(
		'public' => true,
		'menu_position'  => 5,
		'menu_icon'  => 'dashicons-clipboard',
		'supports'  => array('title','editor','thumbnail'),
		'labels' => array(
			'name'      	=> __('Food Menu 1','victory'),
			'all_items' 	=> __('All Item','victory'),
			'add_new'   	=> __('Add Item','victory'),
			'add_new_item'  => __('Add New Item','victory'),
			'edit_item'  => __('Edit Item','victory'),
		),
	));	
	register_post_type('menu-2',array(
		'public' => true,
		'menu_position'  => 5,
		'menu_icon'  => 'dashicons-clipboard',
		'supports'  => array('title','editor','thumbnail'),
		'labels' => array(
			'name'      	=> __('Food Menu 2','victory'),
			'all_items' 	=> __('All Item','victory'),
			'add_new'   	=> __('Add Item','victory'),
			'add_new_item'  => __('Add New Item','victory'),
			'edit_item'  => __('Edit Item','victory'),
		),
	));	
	register_post_type('menu-3',array(
		'public' => true,
		'menu_position'  => 5,
		'menu_icon'  => 'dashicons-clipboard',
		'supports'  => array('title','editor','thumbnail'),
		'labels' => array(
			'name'      	=> __('Food Menu 3','victory'),
			'all_items' 	=> __('All Item','victory'),
			'add_new'   	=> __('Add Item','victory'),
			'add_new_item'  => __('Add New Item','victory'),
			'edit_item'  => __('Edit Item','victory'),
		),
	));
	
	
	
}
add_action('after_setup_theme','victory_function');










function victory_css_and_js_file(){
	
	wp_enqueue_style('victory-bootstrap',get_template_directory_uri().'/css/bootstrap.min.css');
	wp_enqueue_style('victory-bootstrap-theme',get_template_directory_uri().'/css/bootstrap-theme.min.css');
	wp_enqueue_style('victory-fontAwesome',get_template_directory_uri().'/css/fontAwesome.css');
	wp_enqueue_style('victory-hero-slider',get_template_directory_uri().'/css/hero-slider.css');
	wp_enqueue_style('victory-owl-carousel',get_template_directory_uri().'/css/owl-carousel.css');
	wp_enqueue_style('victory-templatemo-style',get_template_directory_uri().'/css/templatemo-style.css');
	wp_enqueue_style('victory-maincss',get_stylesheet_uri());
	
	        

        
		
	
	
	
	wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.4.1.min.js',array('jquery'),'','true');
	
	wp_enqueue_script('victory-modernizr',get_template_directory_uri().'/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js',array('jquery'),'','true');
	
	wp_enqueue_script('victory-bootstrap',get_template_directory_uri().'/js/vendor/bootstrap.min.js',array('jquery'),'','true');
	
	wp_enqueue_script('victory-plugins',get_template_directory_uri().'/js/plugins.js',array('jquery'),'','true');
	
	wp_enqueue_script('victory-main',get_template_directory_uri().'/js/main.js',array('jquery'),'','true');
	
	
	
	
	
	
	
	
    



}
add_action('wp_enqueue_scripts','victory_css_and_js_file');









// require file for cmb2

require_once('lib/init.php');
require_once('lib/config.php');


// require file for options ReduxCore framework


require_once('inc/ReduxCore/framework.php');
require_once('inc/sample/config.php');

// require file for TGM plugin activition


require_once('plugin/config.php');